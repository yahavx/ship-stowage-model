//
// Created by yahav on 13/05/2020.
//

#include "_305170987_a.h"


REGISTER_ALGORITHM(_305170987_a)
