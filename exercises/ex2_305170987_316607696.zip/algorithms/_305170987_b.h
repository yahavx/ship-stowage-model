//
// Created by yahav on 13/05/2020.
//

#ifndef SHIP_STOWAGE_MODEL__305170987_B_H
#define SHIP_STOWAGE_MODEL__305170987_B_H

#include "RobustStowageAlgorithm.h"


/// The algorithm implementation is in the parent class.
class _305170987_b : public RobustStowageAlgorithm {

};


#endif //SHIP_STOWAGE_MODEL__305170987_B_H
