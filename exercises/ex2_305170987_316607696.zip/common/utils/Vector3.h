//
// Created by yahav on 13/05/2020.
//

#ifndef SHIP_STOWAGE_MODEL_VECTOR3_H
#define SHIP_STOWAGE_MODEL_VECTOR3_H


class Vector3 {
protected:
    int x, y, z;

    Vector3();

    Vector3(int x, int y, int z);
};


#endif //SHIP_STOWAGE_MODEL_VECTOR3_H
