//
// Created by yahav on 13/05/2020.
//

#include "Vector3.h"

Vector3::Vector3() {}

Vector3::Vector3(int x, int y, int z) : x(x), y(y), z(z) {}
