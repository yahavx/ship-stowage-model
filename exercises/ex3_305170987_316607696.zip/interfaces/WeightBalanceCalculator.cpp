//
// Created by t-yabeny on 5/5/2020.
//

#include <string>
#include "WeightBalanceCalculator.h"

int WeightBalanceCalculator::readShipPlan(const std::string &full_path_and_file_name) {
    return 0;
    (void)full_path_and_file_name;
}

WeightBalanceCalculator::BalanceStatus WeightBalanceCalculator::tryOperation(char loadUnload, int kg, int x, int y) {
    return APPROVED;
    (void)loadUnload;
    (void)kg;
    (void)x;
    (void)y;
}

