//
// Created by yahav on 13/05/2020.
//

#include "_305170987_a.h"
#include "../interfaces/AlgorithmRegistration.h"


REGISTER_ALGORITHM(_305170987_a)
