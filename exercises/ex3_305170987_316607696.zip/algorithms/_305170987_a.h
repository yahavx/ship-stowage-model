//
// Created by yahav on 13/05/2020.
//

#ifndef SHIP_STOWAGE_MODEL__305170987_A_H
#define SHIP_STOWAGE_MODEL__305170987_A_H

#include "EfficientStowageAlgorithm.h"


/// The algorithm implementation is in the parent class.
class _305170987_a : public EfficientStowageAlgorithm {

};


#endif //SHIP_STOWAGE_MODEL__305170987_A_H
