//
// Created by Orr on 4/17/2020.
//

#include "Position.h"

Position::Position(int x, int y, int z) : x(x), y(y), z(z) {}
