//
// Created by Orr on 4/17/2020.
//

#ifndef SHIP_STOWAGE_MODEL_POSITION_H
#define SHIP_STOWAGE_MODEL_POSITION_H


#include <tuple>

class Position {
public:
    int x, y, z;

    Position(int x, int y, int z);
};


#endif //SHIP_STOWAGE_MODEL_POSITION_H
