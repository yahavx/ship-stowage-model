//
// Created by t-yabeny on 4/20/2020.
//

#include "Constants.h"

const std::string Constants::s_unloadOnly = "UnloadOnly:";