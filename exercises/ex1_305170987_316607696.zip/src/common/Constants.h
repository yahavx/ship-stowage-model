//
// Created by t-yabeny on 4/20/2020.
//

#ifndef SHIP_STOWAGE_MODEL_CONSTANTS_H
#define SHIP_STOWAGE_MODEL_CONSTANTS_H


#include <string>

class Constants {
public:
    static const std::string s_unloadOnly;
};


#endif //SHIP_STOWAGE_MODEL_CONSTANTS_H
